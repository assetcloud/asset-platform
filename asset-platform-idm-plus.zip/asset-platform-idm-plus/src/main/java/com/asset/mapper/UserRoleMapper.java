package com.asset.mapper;

import com.asset.bean.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Component;

@Component
public interface UserRoleMapper extends BaseMapper<UserRole> {
}

package com.asset.mapper;

import com.asset.bean.Mail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface MailMapper extends BaseMapper<Mail> {
}

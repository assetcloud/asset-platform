package com.asset.mapper;

import com.asset.bean.SceneRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hjhu
 * @since 2019-07-29
 */
public interface SceneRelationMapper extends BaseMapper<SceneRelation> {

}

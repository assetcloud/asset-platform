package com.asset.utils;

public interface BaseUtils {
}

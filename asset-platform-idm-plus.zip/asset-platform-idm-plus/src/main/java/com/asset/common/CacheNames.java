package com.asset.common;

public interface CacheNames {

    String NOTICE_ONE = "NOTICE_ONE";

    String DICT_VALUE = "DICT_VALUE";
    String DICT_LIST = "DICT_LIST";
}

package com.asset.service;

import com.asset.bean.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

public interface IUserRoleService extends IService<UserRole> {
}

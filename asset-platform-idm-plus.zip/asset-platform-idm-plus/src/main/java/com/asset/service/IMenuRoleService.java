package com.asset.service;

import com.asset.bean.MenuRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hjhu
 * @since 2019-07-29
 */
public interface IMenuRoleService extends IService<MenuRole> {

}

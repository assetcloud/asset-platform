package com.asset.service;

import com.asset.bean.RoleGroup;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hjhu
 * @since 2019-07-17
 */
public interface IRoleGroupService extends IService<RoleGroup> {

}

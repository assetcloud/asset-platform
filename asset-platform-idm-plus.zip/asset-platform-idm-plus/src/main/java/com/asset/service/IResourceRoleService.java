package com.asset.service;

import com.asset.bean.ResourceRole;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hjhu
 * @since 2019-07-18
 */
public interface IResourceRoleService extends IService<ResourceRole> {

}
